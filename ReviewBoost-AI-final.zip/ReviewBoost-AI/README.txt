ReviewBoost AI - final project
===============================

Live app:    https://review-bost-ai-frontend.vercel.app   (admin: /admin)
Backend API: https://review-boost-ai-backend-production.up.railway.app/docs

STATUS: the whole flow works live. AI drafts currently use the safe fallback
because the Railway GEMINI_API_KEY is invalid (401). Set a valid key to enable
real Gemini drafts. See frontend/docs/DEFENSE.md (top) for the exact steps.

Folders
  frontend/  Next.js 16 app (admin panel + customer panel). See frontend/README.md
  backend/   FastAPI + Gemini + SQLite. See backend/README.md

Start here
  frontend/docs/DEFENSE.md          status, architecture, AI safety, verified results, demo script, examiner Q&A
  frontend/docs/BLUEPRINT_CHECK.md  problem statement vs implementation, item by item

Not included on purpose: node_modules, .next, .git, .env files (secrets), database files.
After unzipping: `npm install` in frontend/ and `pip install -r requirements.txt` in backend/.
